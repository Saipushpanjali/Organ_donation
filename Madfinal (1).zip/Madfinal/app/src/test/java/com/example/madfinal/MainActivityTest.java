package com.example.madfinal;

import junit.framework.TestCase;

public class MainActivityTest extends TestCase

}